Report safety or security issues privately. Do not submit code that performs real-world traffic actuation, network exfiltration, hidden persistence, or enforcement automation.
