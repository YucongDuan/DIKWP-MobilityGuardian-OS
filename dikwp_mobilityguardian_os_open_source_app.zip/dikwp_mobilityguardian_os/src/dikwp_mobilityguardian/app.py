try:
    import streamlit as st
except Exception:  # optional dependency
    st = None

from pathlib import Path
from .analyzer import analyze

if st is None:
    raise SystemExit("Streamlit is not installed. Run: pip install -e .[app]")

st.set_page_config(page_title="DIKWP MobilityGuardian OS", layout="wide")
st.title("DIKWP MobilityGuardian OS")
st.caption("Advisory smart transportation semantic twin. No real-world actuation.")
scenario_path = st.text_input("Scenario JSON path", "examples/sample_corridor_scenario.json")
out_dir = st.text_input("Output directory", "outputs/demo")
if st.button("Analyze"):
    report = analyze(scenario_path, out_dir)
    st.json(report)
    st.success(f"Outputs written to {out_dir}")
