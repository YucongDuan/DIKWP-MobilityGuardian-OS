import argparse
from .analyzer import analyze
from .static_audit import write_audit

def main() -> None:
    parser = argparse.ArgumentParser(prog="mobilityguardian")
    sub = parser.add_subparsers(dest="command", required=True)
    a = sub.add_parser("analyze", help="Analyze a corridor scenario")
    a.add_argument("scenario")
    a.add_argument("--out", default="outputs/demo")
    s = sub.add_parser("static-audit", help="Run static boundary audit")
    s.add_argument("src")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args = parser.parse_args()
    if args.command == "analyze":
        analyze(args.scenario, args.out)
        print(f"Wrote MobilityGuardian outputs to {args.out}")
    elif args.command == "static-audit":
        report = write_audit(args.src, args.out)
        print(f"Static audit pass={report['pass']} findings={report['finding_count']}")

if __name__ == "__main__":
    main()
