from typing import Any

def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))

def norm(value: float, scale: float) -> float:
    if scale <= 0:
        return 0.0
    return clamp(value / scale)

def label_score(score: float) -> str:
    if score >= 0.82:
        return "critical"
    if score >= 0.62:
        return "high"
    if score >= 0.38:
        return "medium"
    return "low"

def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default
