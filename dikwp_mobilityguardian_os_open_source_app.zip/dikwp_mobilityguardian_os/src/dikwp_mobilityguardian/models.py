from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass
class Intersection:
    id: str
    name: str
    avg_queue_m: float = 0.0
    avg_delay_s: float = 0.0
    vehicle_count: int = 0
    pedestrian_wait_s: float = 0.0
    pedestrian_count: int = 0
    cyclist_count: int = 0
    bus_delay_s: float = 0.0
    emergency_vehicle_present: bool = False
    weather: str = "clear"
    school_zone: bool = False
    equity_zone: bool = False
    sensor_confidence: float = 0.75
    notes: str = ""

@dataclass
class Incident:
    id: str
    type: str
    location_intersection_id: str
    severity: int = 1
    lanes_blocked: int = 0
    injuries_reported: bool = False
    vulnerable_user_involved: bool = False
    hazardous_materials: bool = False
    timestamp: str = ""
    source: str = "unknown"

@dataclass
class MobilityScenario:
    city: str
    corridor: str
    timestamp: str
    policy_objectives: List[str]
    intersections: List[Intersection] = field(default_factory=list)
    incidents: List[Incident] = field(default_factory=list)
    notes: str = ""

@dataclass
class MobilityScores:
    congestion: float
    safety_risk: float
    emergency_priority: float
    transit_priority: float
    equity_priority: float
    reliability: float
    composite_priority: float

@dataclass
class AdvisoryAction:
    action_id: str
    intersection_id: str
    action_type: str
    priority: str
    rationale: str
    human_review_required: bool = True
    reversible: bool = True
    kill_condition: str = "If sensor confidence drops, conflicting field reports appear, or authorized operator rejects the advisory."
