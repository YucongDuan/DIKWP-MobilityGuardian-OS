import csv
import json
from pathlib import Path
from typing import Dict, List
from .models import MobilityScenario, Intersection, Incident, MobilityScores
from .text_utils import clamp, norm, label_score
from .redflags import detect_red_flags
from .planner import build_actions
from .dikwp import build_dikwp_record
from .reports import write_markdown_recommendations

def parse_scenario(path: str) -> MobilityScenario:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    intersections = [Intersection(**item) for item in data.get("intersections", [])]
    incidents = [Incident(**item) for item in data.get("incidents", [])]
    return MobilityScenario(
        city=data.get("city", "unknown"),
        corridor=data.get("corridor", "unknown"),
        timestamp=data.get("timestamp", ""),
        policy_objectives=data.get("policy_objectives", ["safety", "mobility", "equity"]),
        intersections=intersections,
        incidents=incidents,
        notes=data.get("notes", ""),
    )

def score_intersection(intersection: Intersection, incidents: List[Incident]) -> MobilityScores:
    incident_load = sum(max(0, min(5, inc.severity)) / 5 for inc in incidents)
    capacity_loss = sum(max(0, inc.lanes_blocked) for inc in incidents)
    congestion = clamp(0.38*norm(intersection.avg_delay_s, 120) + 0.35*norm(intersection.avg_queue_m, 220) + 0.17*norm(intersection.vehicle_count, 900) + 0.10*norm(capacity_loss, 3))
    vru_exposure = clamp(0.5*norm(intersection.pedestrian_count, 120) + 0.5*norm(intersection.cyclist_count, 50))
    weather_risk = 0.25 if intersection.weather.lower() in {"rain", "heavy_rain", "snow", "ice", "fog"} else 0.0
    school_risk = 0.15 if intersection.school_zone else 0.0
    incident_risk = clamp(incident_load / 2.0)
    injury_risk = 0.3 if any(i.injuries_reported or i.vulnerable_user_involved for i in incidents) else 0.0
    safety_risk = clamp(0.30*vru_exposure + 0.25*norm(intersection.pedestrian_wait_s, 140) + 0.20*incident_risk + weather_risk + school_risk + injury_risk)
    emergency_priority = clamp((0.7 if intersection.emergency_vehicle_present else 0.0) + (0.35 if any(i.injuries_reported for i in incidents) else 0.0) + (0.25 if any(i.hazardous_materials for i in incidents) else 0.0))
    transit_priority = clamp(0.75*norm(intersection.bus_delay_s, 480) + 0.25*(1.0 if intersection.equity_zone else 0.0))
    equity_priority = clamp(0.35*(1.0 if intersection.equity_zone else 0.0) + 0.25*norm(intersection.pedestrian_wait_s, 120) + 0.20*norm(intersection.bus_delay_s, 480) + 0.20*vru_exposure)
    reliability = clamp(0.15 + 0.85*intersection.sensor_confidence - 0.15*(1.0 if intersection.notes.lower().find("missing") >= 0 else 0.0))
    composite = clamp(0.32*safety_risk + 0.24*emergency_priority + 0.18*congestion + 0.15*transit_priority + 0.11*equity_priority)
    return MobilityScores(congestion, safety_risk, emergency_priority, transit_priority, equity_priority, reliability, composite)

def analyze(path: str, out_dir: str) -> Dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    scenario = parse_scenario(path)
    incidents_by_intersection: Dict[str, List[Incident]] = {i.id: [] for i in scenario.intersections}
    for inc in scenario.incidents:
        incidents_by_intersection.setdefault(inc.location_intersection_id, []).append(inc)

    records = []
    actions = []
    ledgers = []
    red_flags = []
    for inter in scenario.intersections:
        relevant = incidents_by_intersection.get(inter.id, [])
        scores = score_intersection(inter, relevant)
        flags = detect_red_flags(inter, relevant)
        acts = build_actions(inter, relevant, scores)
        record = {
            "intersection": inter.__dict__,
            "scores": scores.__dict__,
            "priority_label": label_score(scores.composite_priority),
            "red_flags": flags,
            "actions": [a.__dict__ for a in acts],
        }
        records.append(record)
        actions.extend(acts)
        red_flags.extend(flags)
        ledgers.append(build_dikwp_record(scenario, inter, relevant, scores))

    decision = "urgent_escalation" if any(f.get("severity") == "critical" for f in red_flags) else ("human_review_required" if any(r["scores"]["composite_priority"] >= 0.55 for r in records) else "advisory_monitoring")
    report = {
        "system": "DIKWP MobilityGuardian OS",
        "version": "0.1.0",
        "scenario": {"city": scenario.city, "corridor": scenario.corridor, "timestamp": scenario.timestamp, "policy_objectives": scenario.policy_objectives},
        "decision": decision,
        "intersection_count": len(scenario.intersections),
        "incident_count": len(scenario.incidents),
        "red_flag_count": len(red_flags),
        "mean_composite_priority": round(sum(r["scores"]["composite_priority"] for r in records)/max(1, len(records)), 4),
        "action_boundary": "Advisory digital twin only. No direct public-road actuation. Authorized operator review required.",
        "records": records,
    }
    (out/"mobility_guardian_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"dikwp_mobility_ledger.json").write_text(json.dumps(ledgers, ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"signal_advisory_plan.json").write_text(json.dumps([a.__dict__ for a in actions], ensure_ascii=False, indent=2), encoding="utf-8")
    with (out/"intersection_priority_queue.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["intersection_id", "name", "priority", "composite", "safety", "congestion", "emergency", "transit", "equity", "reliability"])
        writer.writeheader()
        for r in sorted(records, key=lambda x: x["scores"]["composite_priority"], reverse=True):
            s = r["scores"]
            writer.writerow({"intersection_id": r["intersection"]["id"], "name": r["intersection"]["name"], "priority": r["priority_label"], "composite": round(s["composite_priority"],4), "safety": round(s["safety_risk"],4), "congestion": round(s["congestion"],4), "emergency": round(s["emergency_priority"],4), "transit": round(s["transit_priority"],4), "equity": round(s["equity_priority"],4), "reliability": round(s["reliability"],4)})
    with (out/"vru_safety_queue.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["intersection_id", "name", "pedestrian_wait_s", "pedestrian_count", "cyclist_count", "safety_risk", "notes"])
        writer.writeheader()
        for r in sorted(records, key=lambda x: x["scores"]["safety_risk"], reverse=True):
            inter = r["intersection"]
            writer.writerow({"intersection_id": inter["id"], "name": inter["name"], "pedestrian_wait_s": inter["pedestrian_wait_s"], "pedestrian_count": inter["pedestrian_count"], "cyclist_count": inter["cyclist_count"], "safety_risk": round(r["scores"]["safety_risk"],4), "notes": inter.get("notes", "")})
    write_markdown_recommendations(out/"mobility_recommendations.md", report)
    return report
