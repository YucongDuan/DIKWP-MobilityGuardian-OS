from typing import Dict, List
from .models import MobilityScenario, Intersection, Incident, MobilityScores

def build_dikwp_record(scenario: MobilityScenario, intersection: Intersection, incidents: List[Incident], scores: MobilityScores) -> Dict:
    return {
        "object": f"intersection:{intersection.id}",
        "D_data": {
            "queue_m": intersection.avg_queue_m,
            "delay_s": intersection.avg_delay_s,
            "vehicle_count": intersection.vehicle_count,
            "pedestrian_wait_s": intersection.pedestrian_wait_s,
            "pedestrian_count": intersection.pedestrian_count,
            "cyclist_count": intersection.cyclist_count,
            "bus_delay_s": intersection.bus_delay_s,
            "weather": intersection.weather,
            "incidents": [i.__dict__ for i in incidents],
            "sensor_confidence": intersection.sensor_confidence,
        },
        "I_information": {
            "relations": [
                "queue-delay relation",
                "vulnerable-road-user exposure relation",
                "transit delay relation",
                "incident-to-capacity relation",
                "weather-to-safety relation",
            ],
            "scores": scores.__dict__,
        },
        "K_knowledge": {
            "traffic_operations": "Use advisory-level prioritization for safety, incident response, transit reliability and multimodal queue reduction.",
            "safe_system": "Human mistakes and vulnerability require layered protection; safety is prioritized before throughput.",
            "incident_management": "Blocked lanes, injuries and emergency vehicles require escalation and human operator review.",
        },
        "W_wisdom": {
            "priority_order": ["life safety", "vulnerable user protection", "emergency response", "transit and accessibility", "general throughput", "emissions and energy reduction"],
            "equity_note": "Pedestrian, cyclist, bus rider and underserved-area impacts must not be hidden behind vehicle throughput averages.",
            "action_boundary": "No direct actuation. All actions are reversible advisory recommendations for authorized operators.",
        },
        "P_purpose": {
            "local_goal": "Move people and goods safely, reliably and accessibly through the corridor.",
            "constraints": ["no autonomous signal control", "human authorization", "source confidence checks", "protect vulnerable users"],
            "feedback": "Compare operator decisions, incident clearance time, delay and near-miss reports after implementation.",
        },
        "R_reliability": {
            "level": "supported" if scores.reliability >= 0.7 else "provisional",
            "confidence": round(scores.reliability, 3),
            "kill": "Conflicting field report, low sensor confidence, missing incident confirmation, or changed road condition.",
        },
    }
