from pathlib import Path
from typing import Dict

def write_markdown_recommendations(path: Path, report: Dict) -> None:
    lines = []
    lines.append("# DIKWP MobilityGuardian Recommendations")
    lines.append("")
    lines.append(f"Decision: **{report['decision']}**")
    lines.append("")
    lines.append("## Action Boundary")
    lines.append(report.get("action_boundary", "Advisory only."))
    lines.append("")
    lines.append("## Priority Intersections")
    for record in sorted(report.get("records", []), key=lambda r: r["scores"]["composite_priority"], reverse=True):
        inter = record["intersection"]
        scores = record["scores"]
        lines.append(f"### {inter['name']} ({inter['id']})")
        lines.append(f"- Composite priority: {scores['composite_priority']:.3f}")
        lines.append(f"- Safety risk: {scores['safety_risk']:.3f}")
        lines.append(f"- Congestion: {scores['congestion']:.3f}")
        lines.append(f"- Transit priority: {scores['transit_priority']:.3f}")
        lines.append(f"- Equity priority: {scores['equity_priority']:.3f}")
        if record.get("red_flags"):
            lines.append("- Red flags:")
            for flag in record["red_flags"]:
                lines.append(f"  - {flag.get('type')}: {flag.get('message')}")
        lines.append("- Advisory actions:")
        for action in record.get("actions", []):
            lines.append(f"  - **{action['priority']}** / {action['action_type']}: {action['rationale']}")
        lines.append("")
    lines.append("## Kill Conditions")
    lines.append("- Sensor confidence drops or source data conflicts with field reports.")
    lines.append("- Authorized operator rejects the advisory.")
    lines.append("- Weather, incident status, emergency priority or road closure status changes.")
    lines.append("- Proposed action would degrade vulnerable-user safety or accessibility.")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
