from typing import Dict, List
from .models import Incident, Intersection

def detect_red_flags(intersection: Intersection, incidents: List[Incident]) -> List[Dict]:
    flags: List[Dict] = []
    for incident in incidents:
        if incident.injuries_reported:
            flags.append({"type": "injury_reported", "severity": "critical", "incident_id": incident.id, "message": "Possible injury incident requires emergency and operator escalation."})
        if incident.hazardous_materials:
            flags.append({"type": "hazardous_materials", "severity": "critical", "incident_id": incident.id, "message": "Hazardous material flag requires specialized emergency review."})
        if incident.vulnerable_user_involved:
            flags.append({"type": "vulnerable_user_involved", "severity": "critical", "incident_id": incident.id, "message": "Pedestrian/cyclist/motorcyclist involvement requires safety-first escalation."})
        if incident.lanes_blocked >= 2 and incident.severity >= 3:
            flags.append({"type": "capacity_loss", "severity": "high", "incident_id": incident.id, "message": "Major capacity loss requires corridor-level advisory plan."})
    if intersection.emergency_vehicle_present:
        flags.append({"type": "emergency_vehicle_present", "severity": "critical", "intersection_id": intersection.id, "message": "Emergency vehicle presence requires authorized emergency signal review."})
    if intersection.pedestrian_wait_s > 110 and (intersection.pedestrian_count + intersection.cyclist_count) > 20:
        flags.append({"type": "vru_delay_exposure", "severity": "high", "intersection_id": intersection.id, "message": "High vulnerable-user delay and exposure requires human review."})
    if intersection.weather.lower() in {"snow", "ice", "fog", "heavy_rain"} and intersection.avg_delay_s > 80:
        flags.append({"type": "weather_safety_degradation", "severity": "high", "intersection_id": intersection.id, "message": "Adverse weather and delay increase crash risk."})
    return flags
