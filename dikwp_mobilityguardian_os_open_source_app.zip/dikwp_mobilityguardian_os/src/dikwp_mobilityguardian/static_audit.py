import ast
import json
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {"socket", "requests", "urllib", "http", "ftplib", "subprocess", "paramiko", "telnetlib"}
FORBIDDEN_CALLS = {"eval", "exec", "system", "popen"}

def audit_tree(src_dir: str) -> Dict:
    root = Path(src_dir)
    findings: List[Dict] = []
    for path in root.rglob("*.py"):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            findings.append({"file": str(path), "type": "syntax_error", "detail": str(exc)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    base = alias.name.split(".")[0]
                    if base in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "detail": alias.name})
            elif isinstance(node, ast.ImportFrom):
                base = (node.module or "").split(".")[0]
                if base in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(path), "type": "forbidden_import", "detail": node.module})
            elif isinstance(node, ast.Call):
                name = ""
                if isinstance(node.func, ast.Name):
                    name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    name = node.func.attr
                if name in FORBIDDEN_CALLS:
                    findings.append({"file": str(path), "type": "forbidden_call", "detail": name})
    return {
        "system": "DIKWP MobilityGuardian OS Static Boundary Audit",
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, host mutation, or real-world traffic actuation helpers.",
    }

def write_audit(src_dir: str, out_path: str) -> Dict:
    report = audit_tree(src_dir)
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report
