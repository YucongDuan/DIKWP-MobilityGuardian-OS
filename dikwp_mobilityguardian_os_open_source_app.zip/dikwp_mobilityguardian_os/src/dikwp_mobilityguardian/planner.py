from typing import List
from .models import AdvisoryAction, Intersection, Incident, MobilityScores
from .text_utils import label_score

def build_actions(intersection: Intersection, incidents: List[Incident], scores: MobilityScores) -> List[AdvisoryAction]:
    actions: List[AdvisoryAction] = []
    base = f"{intersection.id}-"
    if scores.emergency_priority >= 0.7:
        actions.append(AdvisoryAction(
            action_id=base+"emergency-review",
            intersection_id=intersection.id,
            action_type="authorized_emergency_review",
            priority="critical",
            rationale="Emergency vehicle or injury flag detected. Review manual emergency priority / green-wave procedures; do not actuate automatically.",
        ))
    if scores.safety_risk >= 0.55:
        actions.append(AdvisoryAction(
            action_id=base+"vru-protection",
            intersection_id=intersection.id,
            action_type="vulnerable_user_protection_advisory",
            priority=label_score(scores.safety_risk),
            rationale="Safety risk is elevated due to vulnerable-user exposure, weather, school zone, or incident severity.",
        ))
    if scores.transit_priority >= 0.45:
        actions.append(AdvisoryAction(
            action_id=base+"transit-priority",
            intersection_id=intersection.id,
            action_type="transit_signal_priority_review",
            priority=label_score(scores.transit_priority),
            rationale="Bus delay is material. Review transit-priority timing if safety and pedestrian constraints are satisfied.",
        ))
    if scores.congestion >= 0.45:
        actions.append(AdvisoryAction(
            action_id=base+"queue-balancing",
            intersection_id=intersection.id,
            action_type="queue_balancing_advisory",
            priority=label_score(scores.congestion),
            rationale="Queue and delay suggest corridor-level balancing may improve reliability and reduce avoidable energy waste.",
        ))
    if scores.equity_priority >= 0.45:
        actions.append(AdvisoryAction(
            action_id=base+"equity-review",
            intersection_id=intersection.id,
            action_type="accessibility_and_equity_review",
            priority=label_score(scores.equity_priority),
            rationale="Equity-zone, pedestrian, cyclist or transit burdens should be reviewed before throughput-only optimization.",
        ))
    if not actions:
        actions.append(AdvisoryAction(
            action_id=base+"monitor",
            intersection_id=intersection.id,
            action_type="monitor_only",
            priority="low",
            rationale="No urgent signal detected. Continue monitoring and preserve data provenance.",
        ))
    return actions
