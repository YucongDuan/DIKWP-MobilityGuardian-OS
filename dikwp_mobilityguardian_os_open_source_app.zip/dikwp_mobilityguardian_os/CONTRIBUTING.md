Contributions are welcome. Please keep the system advisory-only, evidence-led, and free of hidden actuation or surveillance behavior.
