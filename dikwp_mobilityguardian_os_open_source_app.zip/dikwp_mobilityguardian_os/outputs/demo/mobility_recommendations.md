# DIKWP MobilityGuardian Recommendations

Decision: **urgent_escalation**

## Action Boundary
Advisory digital twin only. No direct public-road actuation. Authorized operator review required.

## Priority Intersections
### Main St / Hospital Rd (I-002)
- Composite priority: 0.738
- Safety risk: 0.805
- Congestion: 0.671
- Transit priority: 0.562
- Equity priority: 0.322
- Red flags:
  - injury_reported: Possible injury incident requires emergency and operator escalation.
  - emergency_vehicle_present: Emergency vehicle presence requires authorized emergency signal review.
- Advisory actions:
  - **critical** / authorized_emergency_review: Emergency vehicle or injury flag detected. Review manual emergency priority / green-wave procedures; do not actuate automatically.
  - **high** / vulnerable_user_protection_advisory: Safety risk is elevated due to vulnerable-user exposure, weather, school zone, or incident severity.
  - **medium** / transit_signal_priority_review: Bus delay is material. Review transit-priority timing if safety and pedestrian constraints are satisfied.
  - **high** / queue_balancing_advisory: Queue and delay suggest corridor-level balancing may improve reliability and reduce avoidable energy waste.

### Main St / Market Blvd (I-003)
- Composite priority: 0.588
- Safety risk: 0.571
- Congestion: 0.933
- Transit priority: 1.000
- Equity priority: 0.793
- Advisory actions:
  - **medium** / vulnerable_user_protection_advisory: Safety risk is elevated due to vulnerable-user exposure, weather, school zone, or incident severity.
  - **critical** / transit_signal_priority_review: Bus delay is material. Review transit-priority timing if safety and pedestrian constraints are satisfied.
  - **critical** / queue_balancing_advisory: Queue and delay suggest corridor-level balancing may improve reliability and reduce avoidable energy waste.
  - **high** / accessibility_and_equity_review: Equity-zone, pedestrian, cyclist or transit burdens should be reviewed before throughput-only optimization.

### Main St / School Ave (I-001)
- Composite priority: 0.512
- Safety risk: 0.799
- Congestion: 0.448
- Transit priority: 0.578
- Equity priority: 0.805
- Red flags:
  - vru_delay_exposure: High vulnerable-user delay and exposure requires human review.
- Advisory actions:
  - **high** / vulnerable_user_protection_advisory: Safety risk is elevated due to vulnerable-user exposure, weather, school zone, or incident severity.
  - **medium** / transit_signal_priority_review: Bus delay is material. Review transit-priority timing if safety and pedestrian constraints are satisfied.
  - **high** / accessibility_and_equity_review: Equity-zone, pedestrian, cyclist or transit burdens should be reviewed before throughput-only optimization.

### Main St / Industrial Way (I-004)
- Composite priority: 0.183
- Safety risk: 0.329
- Congestion: 0.314
- Transit priority: 0.070
- Equity priority: 0.102
- Advisory actions:
  - **low** / monitor_only: No urgent signal detected. Continue monitoring and preserve data provenance.

## Kill Conditions
- Sensor confidence drops or source data conflicts with field reports.
- Authorized operator rejects the advisory.
- Weather, incident status, emergency priority or road closure status changes.
- Proposed action would degrade vulnerable-user safety or accessibility.
