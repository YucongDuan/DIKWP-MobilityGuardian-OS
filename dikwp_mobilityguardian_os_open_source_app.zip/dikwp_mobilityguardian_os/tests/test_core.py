from pathlib import Path
from dikwp_mobilityguardian.analyzer import analyze, parse_scenario
from dikwp_mobilityguardian.static_audit import audit_tree

ROOT = Path(__file__).resolve().parents[1]

def test_parse_scenario():
    scenario = parse_scenario(str(ROOT / "examples" / "sample_corridor_scenario.json"))
    assert scenario.city == "Example City"
    assert len(scenario.intersections) == 4
    assert len(scenario.incidents) == 2

def test_analyze_outputs(tmp_path):
    report = analyze(str(ROOT / "examples" / "sample_corridor_scenario.json"), str(tmp_path))
    assert report["decision"] in {"urgent_escalation", "human_review_required", "advisory_monitoring"}
    assert report["red_flag_count"] >= 1
    assert (tmp_path / "dikwp_mobility_ledger.json").exists()
    assert (tmp_path / "signal_advisory_plan.json").exists()

def test_static_audit_passes():
    report = audit_tree(str(ROOT / "src"))
    assert report["pass"] is True
