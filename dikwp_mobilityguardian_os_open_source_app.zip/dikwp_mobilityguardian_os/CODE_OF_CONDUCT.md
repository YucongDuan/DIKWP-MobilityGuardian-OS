Be respectful, safety-first, and evidence-oriented. Do not use this project to justify unsafe or discriminatory transportation decisions.
