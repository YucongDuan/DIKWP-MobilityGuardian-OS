# Governance Boundary

This application is advisory only. It must not be marketed as a certified signal controller, public safety dispatch system, enforcement system or autonomous mobility-control system.

Forbidden use:

- direct traffic signal actuation without authorized operator review;
- automatic enforcement or profiling;
- hidden surveillance;
- discriminatory prioritization;
- replacing emergency services;
- suppressing vulnerable-road-user delays to improve vehicle throughput metrics.

Required use:

- retain evidence ledger;
- review critical actions manually;
- document source reliability;
- preserve kill/recovery conditions;
- protect privacy and accessibility.
