# Open Source Launch Plan

1. Publish the repository with clear DIKWP attribution.
2. Pin a demo scenario and screenshots.
3. Release a short Chinese and English product brief.
4. Invite transportation planners, traffic engineers, Agent governance teams and civic-tech groups to test.
5. Add connectors only after maintaining the advisory boundary.
6. Build benchmarks for safety-first, equity-aware and energy-aware corridor decisions.
