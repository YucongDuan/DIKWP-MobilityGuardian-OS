# Roadmap

- v0.2: GTFS-RT and CSV input adapters.
- v0.3: OpenTelemetry-style trace export for traffic operations events.
- v0.4: ProofLedger integration for traffic incident evidence.
- v0.5: IntentGuard integration for infrastructure action gating.
- v0.6: MobilityEnergy module for stop-and-go energy waste estimates.
- v1.0: City pilot advisory dashboard with role-based review.
