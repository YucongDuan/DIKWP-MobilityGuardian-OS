# DIKWP Model Mapping

- D: Detector observations, queues, delay, incidents, weather, pedestrian and cyclist exposure.
- I: Conflict relations, priority relations, queue propagation, incident-to-capacity relations.
- K: Safe System approach, incident management, signal operations, transit priority and multimodal planning.
- W: Safety-first prioritization, vulnerable-road-user protection, equity, reversibility and human authorization.
- P: Move people and goods safely, reliably, accessibly and with lower avoidable energy waste.
- R: Sensor confidence, source agreement, missingness, provenance and kill conditions.
