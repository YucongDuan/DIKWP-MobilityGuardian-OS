# Integration Guide

Current version accepts a local JSON scenario file. Future connectors may include:

- traffic detector feeds;
- transit GTFS-RT style feeds;
- incident management systems;
- weather alerts;
- emergency dispatch interfaces;
- pedestrian and cyclist count systems;
- OpenTelemetry-style operations traces.

All external connectors should be implemented as optional modules with explicit consent, provenance and operator review.
