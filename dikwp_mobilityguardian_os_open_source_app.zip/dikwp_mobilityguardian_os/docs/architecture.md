# Architecture

The system has five layers:

1. **Input layer**: corridor scenario JSON, intersection state, incident state, weather, vulnerable user exposure, transit delay.
2. **Scoring layer**: congestion, safety, emergency, transit, equity, reliability and composite priority.
3. **DIKWP ledger layer**: each intersection is registered as Data, Information, Knowledge, Wisdom, Purpose and Reliability.
4. **Advisory planning layer**: generates human-reviewable action cards.
5. **Output layer**: JSON reports, CSV queues and markdown recommendations.

The default implementation is offline and local. It contains no network connectors, no signal controller interface, and no enforcement interface.
