# Release Draft

DIKWP MobilityGuardian OS v0.1.0 is now available.

This release includes an offline corridor analyzer, DIKWP mobility ledger, safety-first scoring, incident and emergency escalation, transit priority advisory, equity queue and static boundary audit.

All outputs are advisory. No real-world traffic actuation is included.
